<?php
require_once 'config.php';
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS')
    exit(0);

$action = $_GET['action'] ?? $_POST['action'] ?? '';

switch ($action) {
    case 'login':
        handleLogin();
        break;
    case 'register':
        handleRegister();
        break;
    case 'dev_register':
        handleDevRegister();
        break;
    case 'logout':
        handleLogout();
        break;
    case 'check':
        handleCheck();
        break;
    default:
        jsonResponse(['success' => false, 'message' => 'Unknown action']);
}

function handleLogin()
{
    $data = json_decode(file_get_contents('php://input'), true) ?? $_POST;
    $email = trim($data['email'] ?? '');
    $password = $data['password'] ?? '';

    if (empty($email) || empty($password)) {
        jsonResponse(['success' => false, 'message' => 'Email va parol kerak']);
    }

    // Admin check
    if ($email === ADMIN_EMAIL && $password === ADMIN_PASS) {
        $_SESSION['user_id'] = 0;
        $_SESSION['username'] = 'Admin';
        $_SESSION['email'] = ADMIN_EMAIL;
        $_SESSION['role'] = 'admin';
        jsonResponse(['success' => true, 'role' => 'admin', 'username' => 'Admin']);
    }

    $conn = getDB();
    $stmt = $conn->prepare("SELECT id, username, email, password, role FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if (!$user || !password_verify($password, $user['password'])) {
        jsonResponse(['success' => false, 'message' => 'Email yoki parol noto\'g\'ri']);
    }

    // Check if dev is approved
    if ($user['role'] === 'dev') {
        $stmt2 = $conn->prepare("SELECT status FROM dev_profiles WHERE user_id = ?");
        $stmt2->bind_param("i", $user['id']);
        $stmt2->execute();
        $devResult = $stmt2->get_result()->fetch_assoc();
        if ($devResult && $devResult['status'] === 'pending') {
            jsonResponse(['success' => false, 'message' => 'Dev profilingiz admin tomonidan hali tasdiqlanmagan']);
        }
        if ($devResult && $devResult['status'] === 'rejected') {
            jsonResponse(['success' => false, 'message' => 'Dev profilingiz rad etilgan. Admin bilan bog\'laning']);
        }
    }

    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['email'] = $user['email'];
    $_SESSION['role'] = $user['role'];

    jsonResponse(['success' => true, 'role' => $user['role'], 'username' => $user['username']]);
}

function handleRegister()
{
    $data = json_decode(file_get_contents('php://input'), true) ?? $_POST;
    $username = trim($data['username'] ?? '');
    $email = trim($data['email'] ?? '');
    $password = $data['password'] ?? '';

    if (empty($username) || empty($email) || empty($password)) {
        jsonResponse(['success' => false, 'message' => 'Barcha maydonlarni to\'ldiring']);
    }
    if (strlen($username) < 3) {
        jsonResponse(['success' => false, 'message' => 'Nickname kamida 3 ta belgi bo\'lishi kerak']);
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        jsonResponse(['success' => false, 'message' => 'Email noto\'g\'ri formatda']);
    }
    if (strlen($password) < 6) {
        jsonResponse(['success' => false, 'message' => 'Parol kamida 6 ta belgi bo\'lishi kerak']);
    }

    $conn = getDB();
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? OR username = ?");
    $stmt->bind_param("ss", $email, $username);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        jsonResponse(['success' => false, 'message' => 'Bu email yoki nickname allaqachon band']);
    }

    $hashed = password_hash($password, PASSWORD_DEFAULT);
    $stmt2 = $conn->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, 'user')");
    $stmt2->bind_param("sss", $username, $email, $hashed);
    if ($stmt2->execute()) {
        jsonResponse(['success' => true, 'message' => 'Ro\'yhatdan muvaffaqiyatli o\'tdingiz! Endi kiring.']);
    } else {
        jsonResponse(['success' => false, 'message' => 'Xatolik yuz berdi, qaytadan urinib ko\'ring']);
    }
}

function handleDevRegister()
{
    $conn = getDB();
    $full_name = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $username = trim($_POST['username'] ?? '');

    if (empty($full_name) || empty($phone) || empty($email) || empty($password) || empty($username)) {
        jsonResponse(['success' => false, 'message' => 'Barcha maydonlarni to\'ldiring']);
    }

    // Check existing
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? OR username = ?");
    $stmt->bind_param("ss", $email, $username);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        jsonResponse(['success' => false, 'message' => 'Bu email yoki username allaqachon band']);
    }

    // Handle logo upload
    $logoPath = '';
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../uploads/dev_logos/';
        if (!is_dir($uploadDir))
            mkdir($uploadDir, 0755, true);
        $ext = pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION);
        $filename = uniqid('dev_') . '.' . $ext;
        if (move_uploaded_file($_FILES['logo']['tmp_name'], $uploadDir . $filename)) {
            $logoPath = 'uploads/dev_logos/' . $filename;
        }
    }

    $hashed = password_hash($password, PASSWORD_DEFAULT);
    $stmt2 = $conn->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, 'dev')");
    $stmt2->bind_param("sss", $username, $email, $hashed);
    $stmt2->execute();
    $userId = $conn->insert_id;

    $stmt3 = $conn->prepare("INSERT INTO dev_profiles (user_id, full_name, phone, logo, status) VALUES (?, ?, ?, ?, 'pending')");
    $stmt3->bind_param("isss", $userId, $full_name, $phone, $logoPath);
    $stmt3->execute();
    $devId = $conn->insert_id;

    // Send notification to admin
    $msg = "Yangi Dev ro'yhatdan o'tish so'rovi: $full_name ($email)";
    $stmt4 = $conn->prepare("INSERT INTO notifications (type, ref_id, message) VALUES ('dev_request', ?, ?)");
    $stmt4->bind_param("is", $devId, $msg);
    $stmt4->execute();

    jsonResponse(['success' => true, 'message' => 'So\'rovingiz yuborildi! Admin tasdiqlashini kuting.']);
}

function handleLogout()
{
    session_destroy();
    jsonResponse(['success' => true]);
}

function handleCheck()
{
    if (isLoggedIn()) {
        jsonResponse([
            'success' => true,
            'logged_in' => true,
            'user' => getCurrentUser()
        ]);
    } else {
        jsonResponse(['success' => true, 'logged_in' => false]);
    }
}
?>