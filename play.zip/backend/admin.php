<?php
require_once 'config.php';
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS')
    exit(0);

// Admin only middleware
function requireAdmin()
{
    if (!isLoggedIn() || $_SESSION['role'] !== 'admin') {
        jsonResponse(['success' => false, 'message' => 'Admin huquqi kerak']);
    }
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

switch ($action) {
    case 'dev_requests':
        requireAdmin();
        devRequests();
        break;
    case 'approve_dev':
        requireAdmin();
        approveDev();
        break;
    case 'reject_dev':
        requireAdmin();
        rejectDev();
        break;
    case 'pending_games':
        requireAdmin();
        pendingGames();
        break;
    case 'all_games':
        requireAdmin();
        allGames();
        break;
    case 'approve_game':
        requireAdmin();
        approveGame();
        break;
    case 'reject_game':
        requireAdmin();
        rejectGame();
        break;
    case 'all_users':
        requireAdmin();
        allUsers();
        break;
    case 'delete_user':
        requireAdmin();
        deleteUser();
        break;
    case 'all_devs':
        requireAdmin();
        allDevs();
        break;
    case 'notifications':
        requireAdmin();
        getNotifications();
        break;
    case 'mark_read':
        requireAdmin();
        markRead();
        break;
    case 'dashboard_stats':
        requireAdmin();
        dashboardStats();
        break;
    default:
        jsonResponse(['success' => false, 'message' => 'Unknown action']);
}

function devRequests()
{
    $conn = getDB();
    $result = $conn->query("SELECT dp.*, u.username, u.email FROM dev_profiles dp JOIN users u ON dp.user_id = u.id WHERE dp.status = 'pending' ORDER BY dp.created_at DESC");
    $requests = [];
    while ($row = $result->fetch_assoc())
        $requests[] = $row;
    jsonResponse(['success' => true, 'requests' => $requests]);
}

function approveDev()
{
    $data = json_decode(file_get_contents('php://input'), true) ?? $_POST;
    $devProfileId = intval($data['id'] ?? 0);
    $conn = getDB();
    $conn->query("UPDATE dev_profiles SET status='approved' WHERE id=$devProfileId");
    $conn->query("UPDATE notifications SET is_read=1 WHERE type='dev_request' AND ref_id=$devProfileId");
    jsonResponse(['success' => true, 'message' => 'Dev profili tasdiqlandi']);
}

function rejectDev()
{
    $data = json_decode(file_get_contents('php://input'), true) ?? $_POST;
    $devProfileId = intval($data['id'] ?? 0);
    $conn = getDB();
    $conn->query("UPDATE dev_profiles SET status='rejected' WHERE id=$devProfileId");
    jsonResponse(['success' => true, 'message' => 'Dev profili rad etildi']);
}

function pendingGames()
{
    $conn = getDB();
    $result = $conn->query("SELECT g.*, u.username as dev_username FROM games g JOIN users u ON g.dev_id = u.id WHERE g.status='pending' ORDER BY g.created_at DESC");
    $games = [];
    while ($row = $result->fetch_assoc()) {
        $row['screenshots'] = json_decode($row['screenshots'] ?? '[]') ?? [];
        $games[] = $row;
    }
    jsonResponse(['success' => true, 'games' => $games]);
}

function allGames()
{
    $conn = getDB();
    $result = $conn->query("SELECT g.*, u.username as dev_username FROM games g JOIN users u ON g.dev_id = u.id ORDER BY g.created_at DESC");
    $games = [];
    while ($row = $result->fetch_assoc()) {
        $row['screenshots'] = json_decode($row['screenshots'] ?? '[]') ?? [];
        $games[] = $row;
    }
    jsonResponse(['success' => true, 'games' => $games]);
}

function approveGame()
{
    $data = json_decode(file_get_contents('php://input'), true) ?? $_POST;
    $gameId = intval($data['id'] ?? 0);
    $conn = getDB();
    $conn->query("UPDATE games SET status='approved' WHERE id=$gameId");
    $conn->query("UPDATE notifications SET is_read=1 WHERE type='game_upload' AND ref_id=$gameId");
    jsonResponse(['success' => true, 'message' => 'O\'yin tasdiqlandi va saytga chiqdi!']);
}

function rejectGame()
{
    $data = json_decode(file_get_contents('php://input'), true) ?? $_POST;
    $gameId = intval($data['id'] ?? 0);
    $conn = getDB();
    $conn->query("UPDATE games SET status='rejected' WHERE id=$gameId");
    jsonResponse(['success' => true, 'message' => 'O\'yin rad etildi']);
}

function allUsers()
{
    $conn = getDB();
    $result = $conn->query("SELECT id, username, email, role, created_at FROM users WHERE role='user' ORDER BY created_at DESC");
    $users = [];
    while ($row = $result->fetch_assoc())
        $users[] = $row;
    jsonResponse(['success' => true, 'users' => $users]);
}

function deleteUser()
{
    $data = json_decode(file_get_contents('php://input'), true) ?? $_POST;
    $userId = intval($data['id'] ?? 0);
    $conn = getDB();
    $conn->query("DELETE FROM users WHERE id=$userId");
    jsonResponse(['success' => true, 'message' => 'Foydalanuvchi o\'chirildi']);
}

function allDevs()
{
    $conn = getDB();
    $result = $conn->query("SELECT dp.*, u.username, u.email FROM dev_profiles dp JOIN users u ON dp.user_id = u.id ORDER BY dp.created_at DESC");
    $devs = [];
    while ($row = $result->fetch_assoc())
        $devs[] = $row;
    jsonResponse(['success' => true, 'devs' => $devs]);
}

function getNotifications()
{
    $conn = getDB();
    $result = $conn->query("SELECT * FROM notifications WHERE is_read=0 ORDER BY created_at DESC LIMIT 20");
    $notifications = [];
    while ($row = $result->fetch_assoc())
        $notifications[] = $row;
    jsonResponse(['success' => true, 'notifications' => $notifications]);
}

function markRead()
{
    $conn = getDB();
    $conn->query("UPDATE notifications SET is_read=1");
    jsonResponse(['success' => true]);
}

function dashboardStats()
{
    $conn = getDB();
    $totalGames = $conn->query("SELECT COUNT(*) as c FROM games WHERE status='approved'")->fetch_assoc()['c'];
    $pendingGames = $conn->query("SELECT COUNT(*) as c FROM games WHERE status='pending'")->fetch_assoc()['c'];
    $totalUsers = $conn->query("SELECT COUNT(*) as c FROM users WHERE role='user'")->fetch_assoc()['c'];
    $totalDevs = $conn->query("SELECT COUNT(*) as c FROM dev_profiles WHERE status='approved'")->fetch_assoc()['c'];
    $pendingDevs = $conn->query("SELECT COUNT(*) as c FROM dev_profiles WHERE status='pending'")->fetch_assoc()['c'];
    $totalPlays = $conn->query("SELECT SUM(plays) as c FROM games")->fetch_assoc()['c'] ?? 0;
    $topGames = $conn->query("SELECT name, plays, status FROM games ORDER BY plays DESC LIMIT 5");
    $top = [];
    while ($row = $topGames->fetch_assoc())
        $top[] = $row;
    jsonResponse(['success' => true, 'stats' => compact('totalGames', 'pendingGames', 'totalUsers', 'totalDevs', 'pendingDevs', 'totalPlays'), 'top_games' => $top]);
}
?>