<?php
define('DB_HOST', 'sql306.infinityfree.com');
define('DB_USER', 'if0_41502294');
define('DB_PASS', '40YNZEi3RLLhh');
define('DB_NAME', 'if0_41502294_oneigamer');

define('ADMIN_EMAIL', 'admin@oneigamer.gd');
define('ADMIN_PASS', 'oneigamer@2010');

// Session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function getDB()
{
    // InfinityFree hosting: connect directly with DB name
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        die(json_encode(['success' => false, 'message' => 'DB ulanishda xato: ' . $conn->connect_error]));
    }
    $conn->set_charset('utf8mb4');
    createTables($conn);
    return $conn;
}

function createTables($conn)
{
    // Users table
    $conn->query("CREATE TABLE IF NOT EXISTS `users` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `username` VARCHAR(50) UNIQUE NOT NULL,
        `email` VARCHAR(100) UNIQUE NOT NULL,
        `password` VARCHAR(255) NOT NULL,
        `role` ENUM('user','dev','admin') DEFAULT 'user',
        `avatar` VARCHAR(255) DEFAULT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB");

    // Dev profiles table
    $conn->query("CREATE TABLE IF NOT EXISTS `dev_profiles` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `user_id` INT NOT NULL,
        `full_name` VARCHAR(150) NOT NULL,
        `phone` VARCHAR(20) NOT NULL,
        `logo` VARCHAR(255) DEFAULT NULL,
        `status` ENUM('pending','approved','rejected') DEFAULT 'pending',
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB");

    // Games table
    $conn->query("CREATE TABLE IF NOT EXISTS `games` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `dev_id` INT NOT NULL,
        `name` VARCHAR(150) NOT NULL,
        `description` TEXT NOT NULL,
        `logo` VARCHAR(255) NOT NULL,
        `screenshots` TEXT DEFAULT NULL,
        `youtube_url` VARCHAR(255) DEFAULT NULL,
        `creator_name` VARCHAR(150) NOT NULL,
        `game_folder` VARCHAR(255) NOT NULL,
        `status` ENUM('pending','approved','rejected') DEFAULT 'pending',
        `plays` INT DEFAULT 0,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (`dev_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB");

    // Admin notifications table
    $conn->query("CREATE TABLE IF NOT EXISTS `notifications` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `type` ENUM('dev_request','game_upload') NOT NULL,
        `ref_id` INT NOT NULL,
        `message` TEXT NOT NULL,
        `is_read` TINYINT(1) DEFAULT 0,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB");
}

function jsonResponse($data)
{
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function isLoggedIn()
{
    return isset($_SESSION['user_id']);
}

function getCurrentUser()
{
    if (!isLoggedIn())
        return null;
    return [
        'id' => $_SESSION['user_id'],
        'username' => $_SESSION['username'],
        'email' => $_SESSION['email'],
        'role' => $_SESSION['role']
    ];
}
?>