<?php
require_once 'config.php';
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS')
    exit(0);

$action = $_GET['action'] ?? $_POST['action'] ?? '';

switch ($action) {
    case 'list':
        listGames();
        break;
    case 'get':
        getGame();
        break;
    case 'upload':
        uploadGame();
        break;
    case 'update':
        updateGame();
        break;
    case 'delete':
        deleteGame();
        break;
    case 'play':
        incrementPlay();
        break;
    case 'dev_games':
        devGames();
        break;
    case 'stats':
        getStats();
        break;
    default:
        jsonResponse(['success' => false, 'message' => 'Unknown action']);
}

function listGames()
{
    $conn = getDB();
    $result = $conn->query("SELECT g.*, u.username as dev_username FROM games g JOIN users u ON g.dev_id = u.id WHERE g.status = 'approved' ORDER BY g.created_at DESC");
    $games = [];
    while ($row = $result->fetch_assoc()) {
        $row['screenshots'] = json_decode($row['screenshots'] ?? '[]') ?? [];
        $games[] = $row;
    }
    jsonResponse(['success' => true, 'games' => $games]);
}

function getGame()
{
    $id = intval($_GET['id'] ?? 0);
    if (!$id)
        jsonResponse(['success' => false, 'message' => 'ID kerak']);
    $conn = getDB();
    $stmt = $conn->prepare("SELECT g.*, u.username as dev_username FROM games g JOIN users u ON g.dev_id = u.id WHERE g.id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $game = $stmt->get_result()->fetch_assoc();
    if (!$game)
        jsonResponse(['success' => false, 'message' => 'O\'yin topilmadi']);
    $game['screenshots'] = json_decode($game['screenshots'] ?? '[]') ?? [];
    jsonResponse(['success' => true, 'game' => $game]);
}

function uploadGame()
{
    if (!isLoggedIn())
        jsonResponse(['success' => false, 'message' => 'Kirish kerak']);
    $user = getCurrentUser();
    if ($user['role'] !== 'dev')
        jsonResponse(['success' => false, 'message' => 'Faqat Dev\'lar o\'yin yuklay oladi']);

    $conn = getDB();
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $creator_name = trim($_POST['creator_name'] ?? '');
    $youtube_url = trim($_POST['youtube_url'] ?? '');
    $dev_id = $user['id'];

    if (empty($name) || empty($description) || empty($creator_name)) {
        jsonResponse(['success' => false, 'message' => 'Barcha maydonlarni to\'ldiring']);
    }

    // Logo upload
    $logoPath = '';
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../uploads/game_logos/';
        if (!is_dir($uploadDir))
            mkdir($uploadDir, 0755, true);
        $ext = pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION);
        $filename = uniqid('logo_') . '.' . $ext;
        if (move_uploaded_file($_FILES['logo']['tmp_name'], $uploadDir . $filename)) {
            $logoPath = 'uploads/game_logos/' . $filename;
        }
    }

    // Screenshots upload
    $screenshots = [];
    if (isset($_FILES['screenshots'])) {
        $ssDir = '../uploads/screenshots/';
        if (!is_dir($ssDir))
            mkdir($ssDir, 0755, true);
        $files = $_FILES['screenshots'];
        for ($i = 0; $i < count($files['name']); $i++) {
            if ($files['error'][$i] === UPLOAD_ERR_OK) {
                $ext = pathinfo($files['name'][$i], PATHINFO_EXTENSION);
                $filename = uniqid('ss_') . '.' . $ext;
                if (move_uploaded_file($files['tmp_name'][$i], $ssDir . $filename)) {
                    $screenshots[] = 'uploads/screenshots/' . $filename;
                }
            }
        }
    }

    // Game ZIP upload
    $gameFolderPath = '';
    if (isset($_FILES['game_zip']) && $_FILES['game_zip']['error'] === UPLOAD_ERR_OK) {
        $gamesDir = '../games/';
        if (!is_dir($gamesDir))
            mkdir($gamesDir, 0755, true);
        $gameId = uniqid('game_');
        $zipPath = $gamesDir . $gameId . '.zip';
        if (move_uploaded_file($_FILES['game_zip']['tmp_name'], $zipPath)) {
            // Extract zip
            $zip = new ZipArchive();
            if ($zip->open($zipPath) === TRUE) {
                $extractPath = $gamesDir . $gameId . '/';
                mkdir($extractPath, 0755, true);
                $zip->extractTo($extractPath);
                $zip->close();
                unlink($zipPath);
                $gameFolderPath = 'games/' . $gameId . '/';
            }
        }
    }

    if (empty($logoPath))
        jsonResponse(['success' => false, 'message' => 'O\'yin logosi kerak']);
    if (empty($gameFolderPath))
        jsonResponse(['success' => false, 'message' => 'O\'yin ZIP fayli kerak']);
    if (count($screenshots) < 2 && empty($youtube_url))
        jsonResponse(['success' => false, 'message' => 'Kamida 2 ta skrinshot yoki YouTube URL kerak']);

    $screenshotsJson = json_encode($screenshots);
    $stmt = $conn->prepare("INSERT INTO games (dev_id, name, description, logo, screenshots, youtube_url, creator_name, game_folder, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
    $stmt->bind_param("isssssss", $dev_id, $name, $description, $logoPath, $screenshotsJson, $youtube_url, $creator_name, $gameFolderPath);
    $stmt->execute();
    $gameId = $conn->insert_id;

    $msg = "Yangi o'yin yuklandi: $name (Dev: {$user['username']})";
    $stmt2 = $conn->prepare("INSERT INTO notifications (type, ref_id, message) VALUES ('game_upload', ?, ?)");
    $stmt2->bind_param("is", $gameId, $msg);
    $stmt2->execute();

    jsonResponse(['success' => true, 'message' => 'O\'yin yuklandi! Admin tasdiqlashini kuting.']);
}

function updateGame()
{
    if (!isLoggedIn())
        jsonResponse(['success' => false, 'message' => 'Kirish kerak']);
    $user = getCurrentUser();
    $conn = getDB();
    $id = intval($_POST['id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');

    $stmt = $conn->prepare("SELECT * FROM games WHERE id = ? AND dev_id = ?");
    $stmt->bind_param("ii", $id, $user['id']);
    $stmt->execute();
    $game = $stmt->get_result()->fetch_assoc();
    if (!$game)
        jsonResponse(['success' => false, 'message' => 'O\'yin topilmadi']);

    $stmt2 = $conn->prepare("UPDATE games SET name=?, description=?, status='pending' WHERE id=?");
    $stmt2->bind_param("ssi", $name, $description, $id);
    $stmt2->execute();
    jsonResponse(['success' => true, 'message' => 'O\'yin yangilandi va qayta tasdiq kutadi']);
}

function deleteGame()
{
    if (!isLoggedIn())
        jsonResponse(['success' => false, 'message' => 'Kirish kerak']);
    $user = getCurrentUser();
    $conn = getDB();
    $id = intval($_POST['id'] ?? 0);

    if ($user['role'] === 'admin') {
        $stmt = $conn->prepare("DELETE FROM games WHERE id=?");
        $stmt->bind_param("i", $id);
    } else {
        $stmt = $conn->prepare("DELETE FROM games WHERE id=? AND dev_id=?");
        $stmt->bind_param("ii", $id, $user['id']);
    }
    $stmt->execute();
    jsonResponse(['success' => true, 'message' => 'O\'yin o\'chirildi']);
}

function incrementPlay()
{
    $id = intval($_POST['id'] ?? 0);
    if (!$id)
        jsonResponse(['success' => false, 'message' => 'ID kerak']);
    $conn = getDB();
    $conn->query("UPDATE games SET plays = plays + 1 WHERE id = $id");
    jsonResponse(['success' => true]);
}

function devGames()
{
    if (!isLoggedIn())
        jsonResponse(['success' => false, 'message' => 'Kirish kerak']);
    $user = getCurrentUser();
    $conn = getDB();
    $stmt = $conn->prepare("SELECT * FROM games WHERE dev_id = ? ORDER BY created_at DESC");
    $stmt->bind_param("i", $user['id']);
    $stmt->execute();
    $games = [];
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $row['screenshots'] = json_decode($row['screenshots'] ?? '[]') ?? [];
        $games[] = $row;
    }
    jsonResponse(['success' => true, 'games' => $games]);
}

function getStats()
{
    if (!isLoggedIn())
        jsonResponse(['success' => false, 'message' => 'Kirish kerak']);
    $user = getCurrentUser();
    $conn = getDB();
    if ($user['role'] === 'admin') {
        $totalGames = $conn->query("SELECT COUNT(*) as c FROM games")->fetch_assoc()['c'];
        $totalUsers = $conn->query("SELECT COUNT(*) as c FROM users WHERE role='user'")->fetch_assoc()['c'];
        $totalDevs = $conn->query("SELECT COUNT(*) as c FROM users WHERE role='dev'")->fetch_assoc()['c'];
        $pendingGames = $conn->query("SELECT COUNT(*) as c FROM games WHERE status='pending'")->fetch_assoc()['c'];
        $totalPlays = $conn->query("SELECT SUM(plays) as c FROM games")->fetch_assoc()['c'] ?? 0;
        jsonResponse(['success' => true, 'stats' => compact('totalGames', 'totalUsers', 'totalDevs', 'pendingGames', 'totalPlays')]);
    } else {
        $stmt = $conn->prepare("SELECT SUM(plays) as total_plays, COUNT(*) as total_games FROM games WHERE dev_id=?");
        $stmt->bind_param("i", $user['id']);
        $stmt->execute();
        $stats = $stmt->get_result()->fetch_assoc();
        jsonResponse(['success' => true, 'stats' => $stats]);
    }
}
?>