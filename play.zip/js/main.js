// ─── API config ───
const API = { auth: 'backend/auth.php', games: 'backend/games.php', admin: 'backend/admin.php' };

async function apiRequest(url, method = 'GET', data = null, isForm = false) {
    const opt = { method, credentials: 'include' };
    if (data && !isForm) { opt.headers = { 'Content-Type': 'application/json' }; opt.body = JSON.stringify(data); }
    else if (data && isForm) { opt.body = data; }
    try { const r = await fetch(url, opt); return await r.json(); }
    catch (e) { return { success: false, message: 'Server bilan aloqa yo\'q. XAMPP ishlaydimi?' }; }
}

// ─── Auth ───
let currentUser = null;

async function checkAuth() {
    const r = await apiRequest(`${API.auth}?action=check`);
    currentUser = (r.success && r.logged_in) ? r.user : null;
    updateNav();
    return currentUser;
}

function updateNav() {
    const el = document.getElementById('nav-actions');
    if (!el) return;
    if (currentUser) {
        el.innerHTML = `
      <div class="user-chip">
        <div class="user-av">${currentUser.username[0].toUpperCase()}</div>
        <span>${currentUser.username}</span>
      </div>
      ${currentUser.role === 'admin' ? `<a href="admin.html" class="btn btn-outline btn-sm"><i class="fa-solid fa-shield-halved"></i> Admin</a>` : ''}
      ${currentUser.role === 'dev' ? `<a href="dev-panel.html" class="btn btn-outline btn-sm"><i class="fa-solid fa-code"></i> Dev Panel</a>` : ''}
      <button class="btn btn-ghost btn-sm" onclick="logout()"><i class="fa-solid fa-right-from-bracket"></i></button>
    `;
    } else {
        el.innerHTML = `
      <a href="login.html" class="btn btn-outline"><i class="fa-solid fa-right-to-bracket"></i> Kirish</a>
      <a href="register.html" class="btn btn-primary"><i class="fa-solid fa-user-plus"></i> Ro'yhat</a>
    `;
    }
}

async function logout() {
    await apiRequest(`${API.auth}?action=logout`);
    currentUser = null;
    window.location.href = 'index.html';
}

// ─── Captcha ───
let capAnswer = null;

function renderCaptcha(containerId) {
    const el = document.getElementById(containerId);
    if (!el) return;
    const ops = ['+', '-', '×'];
    const op = ops[Math.floor(Math.random() * 3)];
    let a = Math.floor(Math.random() * 10) + 1, b = Math.floor(Math.random() * 10) + 1;
    if (op === '-' && b > a) [a, b] = [b, a];
    capAnswer = op === '+' ? a + b : op === '-' ? a - b : a * b;
    el.innerHTML = `
    <label class="flabel">Tekshirish: Hisoblang</label>
    <div class="cap-box">
      <div class="cap-q">${a} ${op} ${b} = ?</div>
      <input id="cap-in" type="number" class="finput cap-ans" placeholder="?">
      <button type="button" class="cap-btn" onclick="renderCaptcha('${containerId}')"><i class="fa-solid fa-rotate"></i></button>
    </div>`;
}

function checkCaptcha() {
    const v = parseInt(document.getElementById('cap-in')?.value);
    return v === capAnswer;
}

// ─── Toast ───
function toast(msg, type = 'info') {
    let c = document.getElementById('toast-c');
    if (!c) {
        c = document.createElement('div');
        c.id = 'toast-c';
        c.style.cssText = 'position:fixed;top:80px;right:1.25rem;z-index:9999;display:flex;flex-direction:column;gap:8px;';
        document.body.appendChild(c);
    }
    const ic = { success: 'fa-circle-check', error: 'fa-circle-xmark', info: 'fa-circle-info', warning: 'fa-triangle-exclamation' };
    const cl = { success: 'ao', error: 'ax', info: 'ai', warning: 'aw' };
    const t = document.createElement('div');
    t.className = `alert ${cl[type] || 'ai'}`;
    t.style.cssText = 'max-width:340px;box-shadow:0 6px 24px rgba(0,0,0,.45);animation:fadeUp .3s ease;';
    t.innerHTML = `<i class="fa-solid ${ic[type] || 'fa-circle-info'}"></i> ${msg}`;
    c.appendChild(t);
    setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; setTimeout(() => t.remove(), 300); }, 3800);
}

// ─── Modals ───
function openModal(id) { document.getElementById(id)?.classList.add('open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('open'); }
document.addEventListener('click', e => { if (e.target.classList.contains('overlay')) e.target.classList.remove('open'); });

// ─── BG Slideshow ───
function initBg() {
    const wrap = document.getElementById('bg-wrap');
    if (!wrap) return;
    const imgs = ['background/1.jpeg', 'background/2.jpg', 'background/3.jpeg', 'background/4.jpg', 'background/5.jpg', 'background/6.jpg'];
    const slides = [];
    imgs.forEach((src, i) => {
        const d = document.createElement('div');
        d.className = 'bg-slide' + (i === 0 ? ' on' : '');
        d.style.backgroundImage = `url('${src}')`;
        wrap.insertBefore(d, wrap.firstChild);
        slides.push(d);
    });
    let cur = 0;
    setInterval(() => {
        slides[cur].classList.remove('on');
        cur = (cur + 1) % slides.length;
        slides[cur].classList.add('on');
    }, 5500);
}

// ─── Init ───
document.addEventListener('DOMContentLoaded', async () => {
    initBg();
    await checkAuth();
});
